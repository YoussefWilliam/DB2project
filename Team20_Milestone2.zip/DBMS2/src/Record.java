
import java.io.Serializable;
import java.util.Hashtable;

public class Record implements Serializable {

	/*
	 * Entries here are 1) name of col 2) value of the record
	 * 
	 */

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Hashtable<String, Object> row;

	public Record(Hashtable<String, Object> row) {
		this.row = row;
	}

}