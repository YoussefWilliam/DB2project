import java.util.Hashtable;
 
public class DBAppTest {
 
  public static void main(String[] args) throws Exception {
    DBApp app = new DBApp("databases/", "DIBO");
 
    String strTableName = "Student";
    Hashtable<String,String> htblColNameType = new Hashtable<>( );
    htblColNameType.put("id", "java.lang.Integer");
    htblColNameType.put("name", "java.lang.String");
    htblColNameType.put("gpa", "java.lang.Double");
    app.createTable( strTableName, "id", htblColNameType ,100 );
    
    Hashtable <String,Object> htblColNameValue = new Hashtable<>();
    htblColNameValue.put("id", new Integer( 2343432 ));
    htblColNameValue.put("name", new String("Ahmed Noor"));
    htblColNameValue.put("gpa", new Double( 0.95 ) );
    
    app.insertIntoTable( strTableName , htblColNameValue);
    htblColNameValue = new Hashtable<>();
    htblColNameValue.put("id", new Integer( 22 ));
    htblColNameValue.put("name", new String("Ahmed Alaa"));
    htblColNameValue.put("gpa", new Double( 1.95 ) );
    app.insertIntoTable( strTableName , htblColNameValue);
    
    app.printTable("Student");
    System.out.println();
    app.deleteFromTable("Student", htblColNameValue);
    app.printTable("Student");
    
    Hashtable<String , Object> hb = new Hashtable<>();
    htblColNameValue = new Hashtable<>();
    htblColNameValue.put("id", new Integer( 1 ));
    htblColNameValue.put("name", new String("Ahmed abdo"));
    htblColNameValue.put("gpa", new Double( 2.95 ) );
    app.updateTable(strTableName, 2343432, htblColNameValue);
    
    System.out.println();
    
    app.printTable("Student");
    
    
    
  }
 
}