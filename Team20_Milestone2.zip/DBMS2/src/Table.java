import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;

public class Table implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */

	String tableName;
	String primaryKey;
	int currentPage = 0;
	int maxRecords;
	String path = "";
	Hashtable<String, String> colType;

	public Table(String path, String name, String primaryKey, Hashtable<String, String> colType, int maxRecords)
			throws IOException {
		this.tableName = name;
		this.primaryKey = primaryKey;
		this.colType = colType;
		this.path += path + "/" + tableName;
		this.maxRecords = maxRecords;
		File fl = new File(path);
		if (fl.exists())
			fl.delete();

		fl.mkdir();

		@SuppressWarnings("unused")
		Page p = new Page(this.path + " " + (++currentPage) + ".class", maxRecords);

		fl = new File(path + ".class");
		fl.createNewFile();
		ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(fl));
		o.writeObject(this);

		o.close();

	}

	public void insert(Hashtable<String, Object> values)
			throws DBAppException, FileNotFoundException, IOException, ClassNotFoundException {

		// 1) check if all types are valid or not
		for (Map.Entry<String, Object> entry : values.entrySet()) {

			String name = entry.getKey();
			if (!colType.containsKey(name))
				throw new DBAppException("You didnot define this col Name before " + name);

			String type = colType.get(name);
			Object currentValue = entry.getValue();
			String actualType = currentValue.getClass().getName();

			if (!actualType.equals(type))
				throw new DBAppException(
						"The type of this object is " + actualType + " and you should give it on type " + type);
		}

		Object uniqueValue = values.get(primaryKey);
		if (uniqueValue == null)
			throw new DBAppException("You should not put null values on Primary key");

		// 2) check in all pages if there are an exist value for primary key or not
		for (int i = 0; i < currentPage; i++) {

			/*
			 * 
			 * 1) READ EACH PAGE BY IT'S CURRENTPAGE (BY READING BINARY FILE
			 * (path+tableName+" "+(currentPage)+".class")) 2) FOR EVERY PAGE WE SHOULD
			 * SEARCH FOR EVERY RECORD FOR THE VALUE OF PRIMARY KEY 3) IF THERE IS AN
			 * ELEMENT EQUALS TO AN ELEMENT IN THE PAGE THEN THROW EXCEPTION
			 */

			File f = new File((path + " " + (i + 1) + ".class"));
			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

			Page p = (Page) oi.readObject();
			TreeMap<Object, Record> currentRecords = p.records;

			oi.close();
			if (currentRecords.containsKey(uniqueValue))
				throw new DBAppException("Primary Key is already exists");

		}

		// 3) insert record

		/*
		 * a) check if number of elements in current page is full or not b) if full then
		 * create another page and add record on it then save it with binary file c) if
		 * not add it to page then delete it from folder and create it again and it was
		 * handled on Page class not here
		 * 
		 * +1
		 */

		File f = new File((this.path + " " + (currentPage) + ".class"));
		ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));
		Page p = (Page) oi.readObject();

		if (p.isFull()) {
			p = new Page(path + " " + (++currentPage) + ".class", maxRecords);

			f = new File((path + " " + (currentPage) + ".class"));

			f.createNewFile();
			ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));
			o.writeObject(p);
			o.close();

		} else {
			p.addRecord(uniqueValue, new Record(values));

		}
		oi.close();

	}

	public void deleteFromTable(String strTableName, Hashtable<String, Object> htblColNameValue)
			throws ClassNotFoundException, IOException, DBAppException {

		Object key = htblColNameValue.get(primaryKey);
		int index = searchCurrentPage(strTableName, key);
		if (index == -1)
			throw new DBAppException("Elements in not found");

		File f = new File((path + " " + (index + 1) + ".class"));
		ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

		Page p = (Page) oi.readObject();
		TreeMap<Object, Record> currentRecords = p.records;
		oi.close();
		currentRecords.remove(key);
		ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));
		o.writeObject(p);
		o.close();
		index++;
		for (int i = index; i < currentPage; i++) {
			File f1 = new File((path + " " + (index) + ".class"));
			ObjectInputStream oi1 = new ObjectInputStream(new FileInputStream(f1));

			Page p1 = (Page) oi1.readObject();
			TreeMap<Object, Record> currentRecords1 = p1.records;

			File f2 = new File((path + " " + (i + 1) + ".class"));
			ObjectInputStream oi2 = new ObjectInputStream(new FileInputStream(f2));

			Page p2 = (Page) oi2.readObject();
			TreeMap<Object, Record> currentRecords2 = p2.records;
			oi1.close();
			oi2.close();

			while ((!p1.isFull()) && (!currentRecords2.isEmpty())) {
				Object key1 = currentRecords2.firstKey();
				Record value1 = currentRecords2.firstEntry().getValue();
				currentRecords2.remove(currentRecords2.firstKey());
				currentRecords1.put(key1, value1);

			}
			ObjectOutputStream o1 = new ObjectOutputStream(new FileOutputStream(f1));
			o1.writeObject(p1);
			ObjectOutputStream o2 = new ObjectOutputStream(new FileOutputStream(f2));
			o2.writeObject(p2);

			o1.close();
			o2.close();

		}
		f = new File((path + " " + (currentPage) + ".class"));
		oi = new ObjectInputStream(new FileInputStream(f));

		p = (Page) oi.readObject();
		if (p.records.isEmpty()) {
			f.delete();
			currentPage--;
		}

	}

	public void updateTable(String strTableName, Object strKey, Hashtable<String, Object> htblColNameValue)
			throws ClassNotFoundException, IOException, DBAppException {

		int index = searchCurrentPage(strTableName, strKey);
		if (index == -1)
			throw new DBAppException("Elements in not found");

		File f = new File((path + " " + (index + 1) + ".class"));
		ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

		Page p = (Page) oi.readObject();
		TreeMap<Object, Record> currentRecords = p.records;
		oi.close();
		htblColNameValue.put(primaryKey, strKey);
		currentRecords.put(strKey, new Record(htblColNameValue));

		ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));
		o.writeObject(p);
		o.close();

	}

	public int searchCurrentPage(String strTableName, Object primaryKey) throws IOException, ClassNotFoundException {
		for (int i = 0; i < currentPage; i++) {
			File f = new File((path + " " + (i + 1) + ".class"));
			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

			Page p = (Page) oi.readObject();
			TreeMap<Object, Record> currentRecords = p.records;
			oi.close();
			if (currentRecords.containsKey(primaryKey))
				return i;
		}
		return -1;

	}

	public void printTable() throws Exception {

		for (int i = 0; i < currentPage; i++)

		{

			File f = new File((path + " " + (i + 1) + ".class"));
			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

			Page p = (Page) oi.readObject();
			TreeMap<Object, Record> currentRecords = p.records;
			oi.close();

			for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
				System.out.println(e.getValue().row);

			}

		}

	}

}
