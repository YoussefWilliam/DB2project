import java.util.Hashtable;
import java.util.Iterator;
 
public class DBAppTest {
 
  public static void main(String[] args) throws Exception {
    DBApp app = new DBApp("databases/", "DIBO");
 
    String strTableName = "Student";
    Hashtable<String,String> htblColNameType = new Hashtable<>( );
    htblColNameType.put("id", "java.lang.Integer");
    htblColNameType.put("name", "java.lang.String");
    htblColNameType.put("gpa", "java.lang.Double");
    app.createTable( strTableName, "id", htblColNameType ,100 );
    app.createBRINIndex( strTableName, "gpa");
    Hashtable <String,Object> htblColNameValue = new Hashtable<>();
    htblColNameValue.put("id", new Integer( 2343432 ));
    htblColNameValue.put("name", new String("Ahmed Noor"));
    htblColNameValue.put("gpa", new Double( 0.95 ) );
    
    app.insertIntoTable( strTableName , htblColNameValue);
    htblColNameValue = new Hashtable<>();
    htblColNameValue.put("id", new Integer( 22 ));
    htblColNameValue.put("name", new String("Ahmed Alaa"));
    htblColNameValue.put("gpa", new Double( 1.95 ) );
    app.insertIntoTable( strTableName , htblColNameValue);
    
    app.printTable("Student");
    System.out.println();
    app.deleteFromTable("Student", htblColNameValue);
    app.printTable("Student");
    
    Hashtable<String , Object> hb = new Hashtable<>();
    htblColNameValue = new Hashtable<>();
    htblColNameValue.put("id", new Integer( 1 ));
    htblColNameValue.put("name", new String("Ahmed abdo"));
    htblColNameValue.put("gpa", new Double( 2.95 ) );
    app.updateTable(strTableName, 2343432, htblColNameValue);
    
    System.out.println();
    Object[]objarrValues = new Object[2];
    objarrValues[0] = new Double( 0.75 );
    objarrValues[1] = new Double( 1.0 );
    String[] strarrOperators = new String[2];
    strarrOperators[0] = ">=";
    strarrOperators[1] = "<";
    // following call to search for 0.75 >= gpa < 1.0
    // always assume operators are Anded, i.e. 0.75 >= gpa && gpa < 1.0
    Iterator resultSet = app.selectFromTable(strTableName, "gpa",
    objarrValues, strarrOperators );
    
    app.printTable("Student");
    
    
    
  }
 
}