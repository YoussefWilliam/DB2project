
import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Hashtable;
import java.util.Iterator;

public class DBApp {

	String path;
	String DBName;
	String currentDB;

	public DBApp(String mainDir, String DBName) throws IOException {
		this.DBName = DBName;
		this.currentDB = mainDir + DBName;

		File db = new File(this.currentDB);
		this.currentDB += "/";
		db.mkdir();

	}

	@SuppressWarnings("unused")
	public void createTable(String strTableName, String primaryKey, Hashtable<String, String> htblColNameType,
			int maxRecords) throws DBAppException, FileNotFoundException, IOException, ClassNotFoundException {

		// 1st:Check if there is an existing table in the databases or not.

		String tableFilePath = currentDB + strTableName;
		File tablePath = new File(tableFilePath);
		if (tablePath.exists()) {
			throw new DBAppException("This database already has this file.");
		} else {
			// 2nd: Create a table and for its file path,Create a new file and
			// add the table inside of it
			Table newTable = new Table(tableFilePath, strTableName, primaryKey, htblColNameType, maxRecords);

		}

	}

	public void insertIntoTable(String strTableName, Hashtable<String, Object> htblColNameValue)
			throws DBAppException, FileNotFoundException, IOException, ClassNotFoundException {

		String tableFilePath = currentDB + strTableName;
		File tablePath = new File(tableFilePath);
		// 1st:Check if there was a table in the databases with that name if not
		// display a msg
		if (!(tablePath.exists())) {
			throw new DBAppException("There is no such table in the databases with this name to insert into it.");
		} else {
			// Fetch the table and insert in it..

			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(tablePath + ".class"));

			Table table = (Table) oi.readObject();

			table.insert(htblColNameValue);
			oi.close();

		}

	}

	public void deleteFromTable(String strTableName, Hashtable<String, Object> htblColNameValue)
			throws DBAppException, FileNotFoundException, IOException, ClassNotFoundException {

		String tableFilePath = currentDB + strTableName;
		File tablePath = new File(tableFilePath);

		if (!(tablePath.exists())) {
			throw new DBAppException("There is no such table in the databases with this name to insert into it.");
		}

		else {
			// Fetch the table and insert in it..

			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(tablePath + ".class"));

			Table table = (Table) oi.readObject();

			table.deleteFromTable(strTableName, htblColNameValue);
			oi.close();

		}

	}

	public void updateTable(String strTableName, Object strKey, Hashtable<String, Object> htblColNameValue)
			throws ClassNotFoundException, IOException, DBAppException {
		String tableFilePath = currentDB + strTableName;
		File tablePath = new File(tableFilePath);

		if (!(tablePath.exists())) {
			throw new DBAppException("There is no such table in the databases with this name to insert into it.");
		}

		else {
			// Fetch the table and insert in it..

			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(tablePath + ".class"));

			Table table = (Table) oi.readObject();

			table.updateTable(strTableName, strKey, htblColNameValue);
			oi.close();

		}

	}

	public void createBRINIndex(String strTableName, String strColName)
			throws DBAppException, FileNotFoundException, IOException, ClassNotFoundException {

		String tableFilePath = currentDB + strTableName;
		File tablePath = new File(tableFilePath);

		if (!(tablePath.exists())) {
			throw new DBAppException("There is no such table in the databases with this name to insert into it.");
		}

		else {
			// Fetch the table and insert in it..

			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(tablePath + ".class"));

			Table table = (Table) oi.readObject();

			table.createBRINIndex(strTableName, strColName);
			;
			oi.close();

		}

	}

	public Iterator selectFromTable(String strTableName, String strColumnName, Object[] objarrValues,
			String[] strarrOperators)
			throws DBAppException, FileNotFoundException, ClassNotFoundException, IOException {
		String tableFilePath = currentDB + strTableName;
		File tablePath = new File(tableFilePath);

		if (!(tablePath.exists())) {
			throw new DBAppException("There is no such table in the databases with this name to insert into it.");
		}


		ObjectInputStream oi = new ObjectInputStream(new FileInputStream(tablePath + ".class"));

		Table table = (Table) oi.readObject();
		oi.close();

		return table.selectFromTable(strTableName, strColumnName, objarrValues, strarrOperators);

	}

	public void printTable(String strTableName) throws Exception {

		String tableFilePath = currentDB + strTableName;
		File tablePath = new File(tableFilePath);
		// 1st:Check if there was a table in the databases with that name if not
		// display a msg
		if (!(tablePath.exists())) {
			throw new DBAppException("There is no such table in the databases with this name to insert into it.");
		} else {
			// Fetch the table and insert in it..

			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(tablePath + ".class"));
			Table table = (Table) oi.readObject();
			oi.close();
			table.printTable();

		}

	}

}

class DBAppException extends Exception {

	private static final long serialVersionUID = -7534757818795868145L;
	String message;

	public DBAppException(String message) {
		super(message);

	}
}