import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.TreeMap;
 
public class Page implements Serializable {
 
  private static final long serialVersionUID = 1L;
 
  // key is primary key of record , Record is a Hashtable contains 1) colName , 2)
  // colValue
 
  /*
   * The idea here we make for each page a TreeMap to save all records
   * 
   * 
   */
 
  TreeMap<Object, Record> records= new TreeMap<>();
 
  int maxSize;
  int index = 0;
  String path; // path for the table folder
 
  public Page(String path, int maxSize) throws IOException {
 
    this.path = path;
    this.maxSize = maxSize;
    File fl = new File(path);
    fl.delete();
    fl.createNewFile();
 
    ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(fl));
    o.writeObject(this);
    o.close();
 
  }
  public boolean isFull() {
	    return records.size() >= maxSize;
	  }
  
	  public boolean addRecord(Object primaryKey, Record record) throws IOException {
	    if (isFull())
	      return false;
	 
	    this.records.put(primaryKey, record);
	    index++;
	 
	    File fl = new File(path); // After creating a record on the page we delete binary file and then create it
	                  // again with new object
	    if (fl.exists())
	      fl.delete();
	    fl.createNewFile();
	    
	    ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(fl));
	    o.writeObject(this);
	    o.close();
	 
	    return true;
	  }
	 
	}
	 