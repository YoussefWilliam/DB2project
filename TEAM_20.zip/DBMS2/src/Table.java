import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class Table implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */

	String tableName;
	String primaryKey;
	int currentPage = 0;
	int maxRecords;
	String path = "";
	Hashtable<String, String> colType;
	// brinIndex for col Name / all records with Triple sorted by gpa (Page number ,
	// primary key , gpa)
	
	HashMap<String, ArrayList<Triple>> index = new HashMap<>();
	HashMap<String, ArrayList<Pair>> brinIndex = new HashMap<>();
	
	public Table(String path, String name, String primaryKey, Hashtable<String, String> colType, int maxRecords)
			throws IOException {
		this.tableName = name;
		this.primaryKey = primaryKey;
		this.colType = colType;
		this.path += path + "/" + tableName;
		this.maxRecords = maxRecords;
		File fl = new File(path);
		if (fl.exists())
			fl.delete();

		fl.mkdir();

		@SuppressWarnings("unused")
		Page p = new Page(this.path + " " + (++currentPage) + ".class", maxRecords);

		fl = new File(path + ".class");
		fl.createNewFile();
		ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(fl));
		o.writeObject(this);

		o.close();

	}

	public void insert(Hashtable<String, Object> values)
			throws DBAppException, FileNotFoundException, IOException, ClassNotFoundException {

		// 1) check if all types are valid or not
		for (Map.Entry<String, Object> entry : values.entrySet()) {

			String name = entry.getKey();
			if (!colType.containsKey(name))
				throw new DBAppException("You didnot define this col Name before " + name);

			String type = colType.get(name);
			Object currentValue = entry.getValue();
			String actualType = currentValue.getClass().getName();

			if (!actualType.equals(type))
				throw new DBAppException(
						"The type of this object is " + actualType + " and you should give it on type " + type);
		}

		Object uniqueValue = values.get(primaryKey);
		if (uniqueValue == null)
			throw new DBAppException("You should not put null values on Primary key");

		// 2) check in all pages if there are an exist value for primary key or not
		for (int i = 0; i < currentPage; i++) {

			/*
			 * 
			 * 1) READ EACH PAGE BY IT'S CURRENTPAGE (BY READING BINARY FILE
			 * (path+tableName+" "+(currentPage)+".class")) 2) FOR EVERY PAGE WE SHOULD
			 * SEARCH FOR EVERY RECORD FOR THE VALUE OF PRIMARY KEY 3) IF THERE IS AN
			 * ELEMENT EQUALS TO AN ELEMENT IN THE PAGE THEN THROW EXCEPTION
			 */

			File f = new File((path + " " + (i + 1) + ".class"));
			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

			Page p = (Page) oi.readObject();
			TreeMap<Object, Record> currentRecords = p.records;

			oi.close();
			if (currentRecords.containsKey(uniqueValue))
				throw new DBAppException("Primary Key is already exists");

		}

		// 3) insert record

		/*
		 * a) check if number of elements in current page is full or not b) if full then
		 * create another page and add record on it then save it with binary file c) if
		 * not add it to page then delete it from folder and create it again and it was
		 * handled on Page class not here
		 * 
		 * +1
		 */
		
		for (int i = 0; i < currentPage; i++) {
			File f = new File((path + " " + (i + 1) + ".class"));
			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));
			
			Page p = (Page) oi.readObject();
			TreeMap<Object, Record> currentRecords = p.records;
			if(currentRecords.isEmpty())
			{
				
				p.addRecord(uniqueValue, new Record(values));
				ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));
				o.writeObject(p);
				o.close();

				
				break;
			}
			
			Map.Entry<Object, Record> first = currentRecords.firstEntry();
			Map.Entry<Object, Record> last = currentRecords.lastEntry();
			
			Object o1 = first.getKey();
			Object o2 = last.getKey();

			if (o1.getClass().toString().equals("java.lang.Integer")) {
				if (((Integer) o1).compareTo((Integer) o2) <= 0 && ((Integer) o2).compareTo((Integer) o1) >= 0) {

					if (!p.isFull()) {
						p.addRecord(uniqueValue, new Record(values));
						ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));
						o.writeObject(p);
						o.close();

					} else {

						Map.Entry<Object, Record> current = currentRecords.lastEntry();
						currentRecords.remove(current);
						p.addRecord(uniqueValue, new Record(values));
						boolean reach = false;
						for (int j = i + 1; j < currentPage; j++) {
							File f1 = new File((path + " " + (j + 1) + ".class"));
							ObjectInputStream oi1 = new ObjectInputStream(new FileInputStream(f1));

							Page p1 = (Page) oi1.readObject();
							TreeMap<Object, Record> currentRecords1 = p1.records;

							if (!p1.isFull()) {
								p1.addRecord(current.getKey(), current.getValue());
								ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f1));
								o.writeObject(p1);
								o.close();
								reach = true;
								break;
							} else {
								Map.Entry<Object, Record> temp = currentRecords1.lastEntry();
								currentRecords1.remove(current);
								p1.addRecord(current.getKey(), current.getValue());
								current = temp;
								ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f1));
								o.writeObject(p1);
								o.close();

							}

						}
						if (!reach) {

							File f2 = new File((this.path + " " + (currentPage) + ".class"));
							ObjectInputStream oi2 = new ObjectInputStream(new FileInputStream(f2));
							Page p2 = (Page) oi2.readObject();
							p2 = new Page(path + " " + (++currentPage) + ".class", maxRecords);

							f2 = new File((path + " " + (currentPage) + ".class"));
							p2.addRecord(current.getKey(), current.getValue());
							f2.createNewFile();
							ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f2));
							o.writeObject(p2);
							o.close();

						}

					}

					break;

				}

			} else if (o1.getClass().toString().equals("java.lang.String")) {

				if (((String) o1).compareTo((String) o2) <= 0 && ((String) o2).compareTo((String) o1) >= 0) {
					if (!p.isFull()) {
						p.addRecord(uniqueValue, new Record(values));
						ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));
						o.writeObject(p);
						o.close();

					} else {

						Map.Entry<Object, Record> current = currentRecords.lastEntry();
						currentRecords.remove(current);
						p.addRecord(uniqueValue, new Record(values));
						boolean reach = false;
						for (int j = i + 1; j < currentPage; j++) {
							File f1 = new File((path + " " + (j + 1) + ".class"));
							ObjectInputStream oi1 = new ObjectInputStream(new FileInputStream(f1));

							Page p1 = (Page) oi1.readObject();
							TreeMap<Object, Record> currentRecords1 = p1.records;

							if (!p1.isFull()) {
								p1.addRecord(current.getKey(), current.getValue());
								ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f1));
								o.writeObject(p1);
								o.close();
								reach = true;
								break;
							} else {
								Map.Entry<Object, Record> temp = currentRecords1.lastEntry();
								currentRecords1.remove(current);
								p1.addRecord(current.getKey(), current.getValue());
								current = temp;
								ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f1));
								o.writeObject(p1);
								o.close();

							}

						}
						if (!reach) {

							File f2 = new File((this.path + " " + (currentPage) + ".class"));
							ObjectInputStream oi2 = new ObjectInputStream(new FileInputStream(f2));
							Page p2 = (Page) oi2.readObject();
							p2 = new Page(path + " " + (++currentPage) + ".class", maxRecords);

							f2 = new File((path + " " + (currentPage) + ".class"));
							p2.addRecord(current.getKey(), current.getValue());
							f2.createNewFile();
							ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f2));
							o.writeObject(p2);
							o.close();

						}

					}

					break;

				}

			} else if (o1.getClass().toString().equals("java.lang.Double")) {
				if (((Double) o1).compareTo((Double) o2) <= 0 && ((Double) o2).compareTo((Double) o1) >= 0) {

					if (!p.isFull()) {
						p.addRecord(uniqueValue, new Record(values));
						ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));
						o.writeObject(p);
						o.close();

					} else {

						Map.Entry<Object, Record> current = currentRecords.lastEntry();
						currentRecords.remove(current);
						p.addRecord(uniqueValue, new Record(values));
						boolean reach = false;
						for (int j = i + 1; j < currentPage; j++) {
							File f1 = new File((path + " " + (j + 1) + ".class"));
							ObjectInputStream oi1 = new ObjectInputStream(new FileInputStream(f1));

							Page p1 = (Page) oi1.readObject();
							TreeMap<Object, Record> currentRecords1 = p1.records;

							if (!p1.isFull()) {
								p1.addRecord(current.getKey(), current.getValue());
								ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f1));
								o.writeObject(p1);
								o.close();
								reach = true;
								break;
							} else {
								Map.Entry<Object, Record> temp = currentRecords1.lastEntry();
								currentRecords1.remove(current);
								p1.addRecord(current.getKey(), current.getValue());
								current = temp;
								ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f1));
								o.writeObject(p1);
								o.close();

							}

						}
						if (!reach) {

							File f2 = new File((this.path + " " + (currentPage) + ".class"));
							ObjectInputStream oi2 = new ObjectInputStream(new FileInputStream(f2));
							Page p2 = (Page) oi2.readObject();
							p2 = new Page(path + " " + (++currentPage) + ".class", maxRecords);

							f2 = new File((path + " " + (currentPage) + ".class"));
							p2.addRecord(current.getKey(), current.getValue());
							f2.createNewFile();
							ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f2));
							o.writeObject(p2);
							o.close();

						}

					}

					break;

				}

			}

			oi.close();

		}

		File f = new File((this.path + " " + (currentPage) + ".class"));
		ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));
		Page p = (Page) oi.readObject();

		if (p.isFull()) {
			p = new Page(path + " " + (++currentPage) + ".class", maxRecords);

			f = new File((path + " " + (currentPage) + ".class"));

			f.createNewFile();
			ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));
			o.writeObject(p);
			o.close();

		} else {
			p.addRecord(uniqueValue, new Record(values));

		}
		oi.close();

	}
	
	public void deleteFromTable(String strTableName, Hashtable<String, Object> htblColNameValue)
			throws ClassNotFoundException, IOException, DBAppException {

		Object key = htblColNameValue.get(primaryKey);
		int index = searchCurrentPage(strTableName, key);
		if (index == -1)
			throw new DBAppException("Elements in not found");

		File f = new File((path + " " + (index + 1) + ".class"));
		ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

		Page p = (Page) oi.readObject();
		TreeMap<Object, Record> currentRecords = p.records;
		oi.close();
		currentRecords.remove(key);
		ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));
		o.writeObject(p);
		o.close();
		index++;
		for (int i = index; i < currentPage; i++) {
			File f1 = new File((path + " " + (index) + ".class"));
			ObjectInputStream oi1 = new ObjectInputStream(new FileInputStream(f1));

			Page p1 = (Page) oi1.readObject();
			TreeMap<Object, Record> currentRecords1 = p1.records;

			File f2 = new File((path + " " + (i + 1) + ".class"));
			ObjectInputStream oi2 = new ObjectInputStream(new FileInputStream(f2));

			Page p2 = (Page) oi2.readObject();
			TreeMap<Object, Record> currentRecords2 = p2.records;
			oi1.close();
			oi2.close();

			while ((!p1.isFull()) && (!currentRecords2.isEmpty())) {
				Object key1 = currentRecords2.firstKey();
				Record value1 = currentRecords2.firstEntry().getValue();
				currentRecords2.remove(currentRecords2.firstKey());
				currentRecords1.put(key1, value1);

			}
			ObjectOutputStream o1 = new ObjectOutputStream(new FileOutputStream(f1));
			o1.writeObject(p1);
			ObjectOutputStream o2 = new ObjectOutputStream(new FileOutputStream(f2));
			o2.writeObject(p2);

			o1.close();
			o2.close();

		}
		f = new File((path + " " + (currentPage) + ".class"));
		oi = new ObjectInputStream(new FileInputStream(f));

		p = (Page) oi.readObject();
		if (p.records.isEmpty()) {
			f.delete();
			currentPage--;
		}
		for(Map.Entry<String, ArrayList<Triple>>e: this.index.entrySet())
			createBRINIndex(tableName, e.getKey());
		
		File fl = new File(path + ".class");
		fl.delete();
		fl.createNewFile();
		ObjectOutputStream oo = new ObjectOutputStream(new FileOutputStream(fl));
		oo.writeObject(this);
		oo.close();
		

	}

	public void updateTable(String strTableName, Object strKey, Hashtable<String, Object> htblColNameValue)
			throws ClassNotFoundException, IOException, DBAppException {

		int index = searchCurrentPage(strTableName, strKey);
		if (index == -1)
			throw new DBAppException("Elements in not found");

		File f = new File((path + " " + (index + 1) + ".class"));
		ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

		Page p = (Page) oi.readObject();
		TreeMap<Object, Record> currentRecords = p.records;
		oi.close();
		htblColNameValue.put(primaryKey, strKey);
		currentRecords.put(strKey, new Record(htblColNameValue));

		ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(f));
		o.writeObject(p);
		o.close();
		
		for(Map.Entry<String, ArrayList<Triple>>e: this.index.entrySet())
			createBRINIndex(tableName, e.getKey());
		
		File fl = new File(path + ".class");
		fl.delete();
		fl.createNewFile();
		ObjectOutputStream oo = new ObjectOutputStream(new FileOutputStream(fl));
		oo.writeObject(this);
		oo.close();



	}

	public int searchCurrentPage(String strTableName, Object primaryKey) throws IOException, ClassNotFoundException {
		for (int i = 0; i < currentPage; i++) {
			File f = new File((path + " " + (i + 1) + ".class"));
			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

			Page p = (Page) oi.readObject();
			TreeMap<Object, Record> currentRecords = p.records;
			oi.close();
			if (currentRecords.containsKey(primaryKey))
				return i;
		}
		return -1;

	}

	public void createBRINIndex(String strTableName, String strColName)
			throws DBAppException, FileNotFoundException, IOException, ClassNotFoundException {
		ArrayList<Triple> triple = new ArrayList<>();
		index.put(strColName, triple);

		for (int i = 0; i < currentPage; i++) {
			File f = new File((path + " " + (i + 1) + ".class"));
			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

			Page p = (Page) oi.readObject();
			TreeMap<Object, Record> currentRecords = p.records;
			oi.close();

			for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
				Object key = e.getKey();
				Record record = e.getValue();
				Hashtable<String, Object> hb = record.row;
				Object obj = hb.get(strColName);

				triple.add(new Triple(i + 1, key, obj));

			}
		}

		Collections.sort(triple);
		ArrayList<Pair> pair = new ArrayList<>();
		brinIndex.put(strColName, pair);
		int index = 0;
		for (int i = 0; i < triple.size(); i += 200) {
			int min = i;
			int max = Math.min(i + 200 - 1, triple.size() - 1);
			pair.add(new Pair(min, max, ++index));

		}
		File fl = new File(path + ".class");
		fl.createNewFile();
		ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(fl));
		o.writeObject(this);

		o.close();
	}

	public Iterator selectFromTable(String strTableName, String strColumnName, Object[] objarrValues,
			String[] strarrOperators)
			throws DBAppException, FileNotFoundException, IOException, ClassNotFoundException {

		ArrayList<Record> iter = new ArrayList<>();

		for (int i = 0; i < objarrValues.length; i++) {
			if (strarrOperators[i].equals(">")) {

				Object o = objarrValues[i];

				if (o.getClass().toString().equals("java.lang.Integer")) {
					int x = (int) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if ((int) variable > x)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!((int) variable > x))
									iter.remove(record);

							}
					}

				} else if (o.getClass().toString().equals("java.lang.String")) {
					String s = (String) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (((String) variable).compareTo(s) > 0)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!(((String) variable).compareTo(s) > 0))
									iter.remove(record);

							}
					}

				} else {
					double d = (double) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if ((double) variable > d)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!((double) variable > d))
									iter.remove(record);

							}

					}
				}

			}

			else

			if (strarrOperators[i].equals("<")) {

				Object o = objarrValues[i];

				if (o.getClass().toString().equals("java.lang.Integer")) {
					int x = (int) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if ((int) variable < x)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!((int) variable < x))
									iter.remove(record);

							}
					}

				} else if (o.getClass().toString().equals("java.lang.String")) {
					String s = (String) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (((String) variable).compareTo(s) < 0)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!(((String) variable).compareTo(s) < 0))
									iter.remove(record);

							}
					}

				} else {
					double d = (double) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if ((double) variable < d)
									iter.add(record);

							}
						else
							for(int l = 0 ;l<iter.size() ; l++)
							{

								Hashtable<String, Object> hb = iter.get(l).row;
								Object variable = hb.get(strColumnName);
								if (!((double) variable < d)) {
									iter.remove(iter.get(l));
									l--;
								}

							}

					}
				}

			} else

			if (strarrOperators[i].equals(">=")) {

				Object o = objarrValues[i];

				if (o.getClass().toString().equals("java.lang.Integer")) {
					int x = (int) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if ((int) variable > x)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!((int) variable >= x))
									iter.remove(record);

							}
					}

				} else if (o.getClass().toString().equals("java.lang.String")) {
					String s = (String) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (((String) variable).compareTo(s) >= 0)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!(((String) variable).compareTo(s) >= 0))
									iter.remove(record);

							}
					}

				} else {
					double d = (double) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if ((double) variable >= d)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!((double) variable >= d))
									iter.remove(record);

							}

					}
				}

			} else if (strarrOperators[i].equals("<=")) {

				Object o = objarrValues[i];

				if (o.getClass().toString().equals("java.lang.Integer")) {
					int x = (int) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if ((int) variable <= x)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!((int) variable <= x))
									iter.remove(record);

							}
					}

				} else if (o.getClass().toString().equals("java.lang.String")) {
					String s = (String) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (((String) variable).compareTo(s) > 0)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!(((String) variable).compareTo(s) <= 0))
									iter.remove(record);

							}
					}

				} else {
					double d = (double) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if ((double) variable > d)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!((double) variable <= d))
									iter.remove(record);

							}

					}
				}

			} else if (strarrOperators[i].equals("==")) {

				Object o = objarrValues[i];

				if (o.getClass().toString().equals("java.lang.Integer")) {
					int x = (int) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if ((int) variable == x)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!((int) variable == x))
									iter.remove(record);

							}
					}

				} else if (o.getClass().toString().equals("java.lang.String")) {
					String s = (String) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (((String) variable).compareTo(s) == 0)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!(((String) variable).compareTo(s) == 0))
									iter.remove(record);

							}
					}

				} else {
					double d = (double) o;
					for (int j = 0; j < currentPage; j++) {
						File f = new File((path + " " + (j + 1) + ".class"));
						ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

						Page p = (Page) oi.readObject();
						TreeMap<Object, Record> currentRecords = p.records;
						oi.close();
						if (i == 0)
							for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
								Record record = e.getValue();
								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if ((double) variable > d)
									iter.add(record);

							}
						else
							for (Record record : iter) {

								Hashtable<String, Object> hb = record.row;
								Object variable = hb.get(strColumnName);
								if (!((double) variable == d))
									iter.remove(record);

							}

					}
				}

			}
		}

		return iter.iterator();

	}

	public void printTable() throws Exception {

		for (int i = 0; i < currentPage; i++)

		{

			File f = new File((path + " " + (i + 1) + ".class"));
			ObjectInputStream oi = new ObjectInputStream(new FileInputStream(f));

			Page p = (Page) oi.readObject();
			TreeMap<Object, Record> currentRecords = p.records;
			oi.close();

			for (Map.Entry<Object, Record> e : currentRecords.entrySet()) {
				System.out.println(e.getValue().row);

			}

		}

	}

	class Pair implements Comparable<Pair> {
		int from;
		int to;
		int pageNumber;

		public Pair(int from, int to, int pageNumber) {

			this.from = from;
			this.to = to;
			this.pageNumber = pageNumber;
		}

		@Override
		public int compareTo(Pair o) {
			return this.from - from;

		}

	}

}

class Triple implements Comparable<Triple> {
	int pageNum;
	Object primaryKey;
	Object index;

	public Triple(int pageNum, Object primaryKey, Object index) {
		this.pageNum = pageNum;
		this.primaryKey = primaryKey;
		this.index = index;
	}

	@Override
	public int compareTo(Triple t) {
		if (this.index.getClass().toString().equals("java.lang.Integer"))
			return (int) this.index - (int) t.index;
		else if (this.index.getClass().toString().equals("java.lang.String"))
			return ((String) this.index).compareTo((String) t.index);
		return ((Double) this.index).compareTo((Double) t.index);
	}
}

class Pair implements Comparable<Pair> {
	Object from;
	Object to;
	int pageNumber;

	public Pair(Object from, Object to, int pageNumber) {

		this.from = from;
		this.to = to;
		this.pageNumber = pageNumber;
	}

	@Override
	public int compareTo(Pair t) {
		if (this.from.getClass().toString().equals("java.lang.Integer"))
			return (int) this.from - (int) t.from;
		else if (this.from.getClass().toString().equals("java.lang.String"))
			return ((String) this.from).compareTo((String) t.from);
		return ((Double) this.from).compareTo((Double) t.from);

	}

}
